const myButton = document.getElementById('myButton');

//*adding event listener to the button
myButton.addEventListener('click', function(){
    alert('Button was clicked!');
}); 
