let name = 'sai kumar';
console.log(`Hello ${name}, good morning!!`);

let age = 22;
console.log(`I am ${age} years old`);

let isIndian = true;
console.log(`Yes i'm indian ${isIndian}`);