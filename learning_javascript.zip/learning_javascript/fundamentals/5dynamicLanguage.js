//Javascript is a dynamically typed language meaning you need to tell js what data type a variable is holding.
//JS engine automatically understands it

var v = 'sai kumar';
console.log(typeof v);

var v = 123;
console.log(typeof v);

//in other languages like java,dart we explicitily tell the data type