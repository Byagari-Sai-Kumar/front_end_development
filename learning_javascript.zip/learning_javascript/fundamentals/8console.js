//everything in js is an object
//we often use console

console.log('Hello world');
//here console is an object where log is the method of that object

//here are the few methods of console

console.log('Hello');
console.error('Error found here');
console.warn('Warning');
console.trace('stack trace');
console.debug();