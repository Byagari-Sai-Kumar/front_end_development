var name = 'Rahul';
console.log(name);