function greet(){
    console.log("Hello sai kumar");
}
